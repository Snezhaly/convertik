﻿using System;

namespace ulearn2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int exponent = int.Parse(Console.ReadLine());
            Console.WriteLine(WhilePow(num, exponent));
        }

        static double WhilePow(int num, int exponent)
        {
            if (exponent == 0) return 1;
            var tail = 1;
            while (exponent > 1)
            {
                if (exponent % 2 == 1)
                    tail *= num;
                num *= num;
                exponent /= 2;
            }
            return num * tail;
        }

    }

}