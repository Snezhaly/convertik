﻿using System;

namespace ulearn1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int exponent = int.Parse(Console.ReadLine());
            Console.WriteLine(WhilePow(num, exponent));
        }

        static double WhilePow(int num, int exponent)
        {
            if (exponent == 0) return 1;
            if (exponent % 2 == 0)
            {
                var tail = (int)WhilePow(num, exponent / 2);
                return tail * tail;
            }
            else return num * WhilePow(num, exponent - 1);
        }

    }

}